package com.springboot.springdata.onlinemovieticketbookingdemo.service;

import org.hibernate.usertype.UserType;

import com.springboot.springdata.onlinemovieticketbookingdemo.entity.User;

public interface UserService {

	User registerNewUser(User use);

	String login(UserType user);
	
	String logout(User user);

	static void save(User theUser) {
		// TODO Auto-generated method stub
		
	}

}
