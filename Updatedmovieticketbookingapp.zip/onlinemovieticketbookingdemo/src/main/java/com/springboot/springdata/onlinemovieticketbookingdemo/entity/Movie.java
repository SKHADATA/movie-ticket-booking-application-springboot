package com.springboot.springdata.onlinemovieticketbookingdemo.entity;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Table(name = "movie_details")
public class Movie {
	
	@Id
	@Column(name="movieId")
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator = "movieId_generator")
	@SequenceGenerator(name="movieId_generator",initialValue = 3000,allocationSize = 1,sequenceName = "movieId_seq")
	
	private Integer movieId;
	private String movieName;
	
	@DateTimeFormat(pattern = "yyyy/MMM/dd")
	private LocalDate movieDirector;
	private Integer movieLength;
	
	@DateTimeFormat(pattern = "yyyy/MMM/dd")
	private LocalDate movieReleaseDate;
	private String langauges;
		
	@ManyToOne
	@JoinColumn(name = "theater_id")
	private Theater theater;

	public Movie() {
	}

	public Movie(Integer movieId, String movieName, LocalDate movieDirector, Integer movieLength,
			LocalDate movieReleaseDate, String langauges, Theater theater) {
		super();
		this.movieId = movieId;
		this.movieName = movieName;
		this.movieDirector = movieDirector;
		this.movieLength = movieLength;
		this.movieReleaseDate = movieReleaseDate;
		this.langauges = langauges;
		this.theater = theater;
	}

	public Movie(Integer movieId, String movieName, LocalDate movieDirector, Integer movieLength,
			LocalDate movieReleaseDate, String langauges) {
		this.movieId = movieId;
		this.movieName = movieName;
		this.movieDirector = movieDirector;
		this.movieLength = movieLength;
		this.movieReleaseDate = movieReleaseDate;
		this.langauges = langauges;
	}
	public Movie(String movieName, LocalDate movieDirector, Integer movieLength,
			LocalDate movieReleaseDate, String langauges, Theater theater) {
		this.movieName = movieName;
		this.movieDirector = movieDirector;
		this.movieLength = movieLength;
		this.movieReleaseDate = movieReleaseDate;
		this.langauges = langauges;
		this.theater= theater;
	}

	public Movie( String movieName, Integer movieLength, String langauges) {
		this.movieName = movieName;
		this.movieLength = movieLength;
		this.langauges = langauges;
	}

	@Override
	public String toString() {
		return "Movie [movieId=" + movieId + ", movieName=" + movieName + ", movieDirector=" + movieDirector
				+ ", movieLength=" + movieLength + ", movieReleaseDate=" + movieReleaseDate + ", langauges=" + langauges
				+ "]";
	}

	public Integer getMovieId() {
		return movieId;
	}

	public void setMovieId(Integer movieId) {
		this.movieId = movieId;
	}

	public String getMovieName() {
		return movieName;
	}

	public void setMovieName(String movieName) {
		this.movieName = movieName;
	}

	public LocalDate getMovieDirector() {
		return movieDirector;
	}

	public void setMovieDirector(LocalDate movieDirector) {
		this.movieDirector = movieDirector;
	}

	public Integer getMovieLength() {
		return movieLength;
	}

	public void setMovieLength(Integer movieLength) {
		this.movieLength = movieLength;
	}

	public LocalDate getMovieReleaseDate() {
		return movieReleaseDate;
	}

	public void setMovieReleaseDate(LocalDate movieReleaseDate) {
		this.movieReleaseDate = movieReleaseDate;
	}

	public String getLangauges() {
		return langauges;
	}

	public void setLangauges(String langauges) {
		this.langauges = langauges;
	}

	public Theater getTheater() {
		return theater;
	}

	public void setTheater(Theater theater) {
		this.theater = theater;
	}	
}
