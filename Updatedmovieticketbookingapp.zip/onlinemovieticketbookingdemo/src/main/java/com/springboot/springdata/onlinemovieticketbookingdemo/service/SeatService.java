package com.springboot.springdata.onlinemovieticketbookingdemo.service;

public interface SeatService {

}
