package com.springboot.springdata.onlinemovieticketbookingdemo.service;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.springboot.springdata.onlinemovieticketbookingdemo.entity.Booking;
import com.springboot.springdata.onlinemovieticketbookingdemo.entity.Customer;
import com.springboot.springdata.onlinemovieticketbookingdemo.entity.Theater;

@Service
@Transactional
public class CustomerServiceImpl implements CustomerService {

	@Override
	public List<Theater> chooseCity(String city) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Booking> deleteBooking(Integer bookingId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void save(Customer theCustomer) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Customer findById(int customerId) {
		// TODO Auto-generated method stub
		return null;
	}

}