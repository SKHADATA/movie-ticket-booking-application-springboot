package com.springboot.springdata.onlinemovieticketbookingdemo.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.springboot.springdata.onlinemovieticketbookingdemo.entity.Booking;

@Service
public interface BookingService {
    List<Booking> getAllBookings();

    Booking getBookingById(Long booking_id);

    Booking pushBooking(Booking newBooking);

    Booking updateBooking(Booking updatedBooking, Long booking_id);

    void deleteBookingById(Long booking_id);

	static List<Booking> getBookingId(Integer bookingId) {
		// TODO Auto-generated method stub
		return null;
	}

	Booking findById(int bookingId);

	List<Booking> findAll();

	void save(Booking theBooking);

	void deleteById(int bookingId);
}