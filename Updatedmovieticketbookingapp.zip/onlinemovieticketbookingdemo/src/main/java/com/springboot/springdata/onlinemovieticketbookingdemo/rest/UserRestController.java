package com.springboot.springdata.onlinemovieticketbookingdemo.rest;

import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.springboot.springdata.onlinemovieticketbookingdemo.entity.User;
import com.springboot.springdata.onlinemovieticketbookingdemo.service.UserService;

@Service
@RestController
public class UserRestController {

	/*private BookingService bookingService;
	
	@Autowired
	public UserRestController(BookingService theBookingService) {
		bookingService = theBookingService;
	}
	
	
	@GetMapping("/bookingId")
	public List<Booking> findAll() {
		return bookingService.findAll();
	}

	// add mapping for GET /employees/{employeeId}
	
	@GetMapping("/Booking/{bookingId}")
	public Booking getBooking(@PathVariable int bookingId) {
		
		Booking theBooking = bookingService.findById(bookingId);
		
		if (theBooking == null) {
			throw new RuntimeException("Booking id not found - " + bookingId);
		}
		
		return theBooking;
	}*/
	
	
	
	@PostMapping("/userId")
	public User addUser(@RequestBody User theUser) {
		
		theUser.setUserId(0);
		
	UserService.save(theUser);
		
		return theUser;
	}
	
	/*@PutMapping("/bookingId")
	public Booking updateBooking(@RequestBody Booking theBooking) {
		
		bookingService.save(theBooking);
		
		return theBooking;
	}
	
	@DeleteMapping("/booking/{bookingId}")
	public String deleteBooking(@PathVariable int bookingId) {
		
		Booking tempBooking = bookingService.findById(bookingId);
		
		// throw exception if null
		
		if (tempBooking == null) {
			throw new RuntimeException("Booking id not found - " + bookingId);
		}
		
		bookingService.deleteById(bookingId);
		
		return "Deleted booking id - " + bookingId;
	}*/
	
}