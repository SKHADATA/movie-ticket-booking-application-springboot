package com.springboot.springdata.onlinemovieticketbookingdemo.rest;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.springboot.springdata.onlinemovieticketbookingdemo.entity.Customer;
import com.springboot.springdata.onlinemovieticketbookingdemo.entity.Theater;
import com.springboot.springdata.onlinemovieticketbookingdemo.service.CustomerService;

@RestController
@RequestMapping("/user/customer")
public class CustomerRestController {
	@Autowired
	CustomerService customerService;
	
	@GetMapping("/city/{city}")
	public List<Theater> getTheaters(@PathVariable String city)
	{
		return customerService.chooseCity(city);
	}
	

	@PostMapping("/customerId")
	public Customer addCustomer(@RequestBody Customer theCustomer) {
		
		theCustomer.setBookingid(0);
		
		customerService.save(theCustomer);
		
		return theCustomer;
	}
	
	@PutMapping("/customerId")
	public Customer updateCustomer(@RequestBody Customer theCustomer) {
		
		customerService.save(theCustomer);
		
		return theCustomer;
	}
	
	@DeleteMapping("/customer/{customerId}")
	public String deleteCustomer(@PathVariable int customerId) {
		
		Customer tempCustomer = customerService.findById(customerId);
		
		// throw exception if null
		
		if (tempCustomer == null) {
			throw new RuntimeException("Customer id not found - " + customerId);
		}
		
		customerService.deleteBooking(customerId);
		
		return "Deleted booking id - " + customerId;
	}
	
}