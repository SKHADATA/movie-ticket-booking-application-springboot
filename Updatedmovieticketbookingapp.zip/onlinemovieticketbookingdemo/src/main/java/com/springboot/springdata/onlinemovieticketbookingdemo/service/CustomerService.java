package com.springboot.springdata.onlinemovieticketbookingdemo.service;

import java.util.List;

import com.springboot.springdata.onlinemovieticketbookingdemo.entity.Booking;
import com.springboot.springdata.onlinemovieticketbookingdemo.entity.Customer;
import com.springboot.springdata.onlinemovieticketbookingdemo.entity.Theater;

public interface CustomerService {

	List<Theater> chooseCity(String city);

	List<Booking> deleteBooking(Integer bookingId);

	void save(Customer theCustomer);

	Customer findById(int customerId);

}
