package com.springboot.springdata.onlinemovieticketbookingdemo.entity;
import java.sql.Time;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Table(name = "show_details")
public class Show {

	@Id
	@Column(name="showId")
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator = "showId_generator")
	@SequenceGenerator(name="showId_generator",initialValue = 2000300040,allocationSize = 1000101,sequenceName = "showId_seq")
	

	private Integer showId;
	@DateTimeFormat(pattern = "hh:mm:ss")
	private Time showStartTime;
	@DateTimeFormat(pattern = "hh:mm:ss")
	private Time showEndTime;
	private String showName;
	private String movieName;
//	private Integer screenId;
	private Integer theaterId;
	
    @OneToMany(mappedBy = "show", cascade = CascadeType.ALL)
	private Set<Seat> seats= new HashSet<>();
    
	@ManyToOne
	@JoinColumn(name = "screen_id")
	private Screen screen;

	public Show() {
	}

	@Override
	public String toString() {
		return "Show [showId=" + showId + ", showStartTime=" + showStartTime + ", showEndTime=" + showEndTime
				+ ", showName=" + showName + ", movieName=" + movieName + ", theaterId=" + theaterId + ", seats="
				+ seats + ", screen=" + screen + "]";
	}

	public Show(Integer showId, Time showStartTime, Time showEndTime, String showName, String movieName,
			Integer theaterId, Set<Seat> seats, Screen screen) {
		super();
		this.showId = showId;
		this.showStartTime = showStartTime;
		this.showEndTime = showEndTime;
		this.showName = showName;
		this.movieName = movieName;
		this.theaterId = theaterId;
		this.seats = seats;
		this.screen = screen;
	}
	public Show(Time showStartTime, Time showEndTime, String showName, String movieName, Integer theaterId) {
		super();
		this.showStartTime = showStartTime;
		this.showEndTime = showEndTime;
		this.showName = showName;
		this.movieName = movieName;
		//this.screenId = screenId;
		this.theaterId = theaterId;
		}

	public Integer getShowId() {
		return showId;
	}

	public void setShowId(Integer showId) {
		this.showId = showId;
	}

	public Time getShowStartTime() {
		return showStartTime;
	}

	public void setShowStartTime(Time showStartTime) {
		this.showStartTime = showStartTime;
	}

	public Time getShowEndTime() {
		return showEndTime;
	}

	public void setShowEndTime(Time showEndTime) {
		this.showEndTime = showEndTime;
	}

	public String getShowName() {
		return showName;
	}

	public void setShowName(String showName) {
		this.showName = showName;
	}

	public String getMovieName() {
		return movieName;
	}

	public void setMovieName(String movieName) {
		this.movieName = movieName;
	}

	public Integer getTheaterId() {
		return theaterId;
	}

	public void setTheaterId(Integer theaterId) {
		this.theaterId = theaterId;
	}

	public Set<Seat> getSeats() {
		return seats;
	}

	public void setSeats(Set<Seat> seats) {
		this.seats = seats;
	}

	public Screen getScreen() {
		return screen;
	}

	public void setScreen(Screen screen) {
		this.screen = screen;
	}

	public void addSeat(Seat seat) {
		seat.setShow(this);
		seats.add(seat);
		
	}

}
