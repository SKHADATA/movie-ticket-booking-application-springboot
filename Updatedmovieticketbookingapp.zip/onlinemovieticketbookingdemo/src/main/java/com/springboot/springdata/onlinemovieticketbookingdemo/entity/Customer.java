package com.springboot.springdata.onlinemovieticketbookingdemo.entity;

import java.time.LocalDate;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "customer_details")
public class Customer {
	
	@Id
	@GeneratedValue
	private String customerId;
	private String customerName;
	private String customerPassword;
	private String customerContact;
	
//	private List<Ticket> myTickets;

	public Customer() {
	}

	@Override
	public String toString() {
		return "Customer [customerId=" + customerId + ", customerName=" + customerName + ", customerPassword="
				+ customerPassword + ",customerContact=" + customerContact
				+ "]";
	}

	public Customer(String customerId, String customerName, String customerPassword, LocalDate dateOfBirth,
			String customerContact, List<Ticket> myTickets) {
		super();
		this.customerId = customerId;
		this.customerName = customerName;
		this.customerPassword = customerPassword;
		this.customerContact = customerContact;
		
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getCustomerPassword() {
		return customerPassword;
	}

	public void setCustomerPassword(String customerPassword) {
		this.customerPassword = customerPassword;
	}

	public String getCustomerContact() {
		return customerContact;
	}

	public void setCustomerContact(String customerContact) {
		this.customerContact = customerContact;
	}

	public void setBookingid(int i) {
		// TODO Auto-generated method stub
		
	}

	
}
