package com.springboot.springdata.onlinemovieticketbookingdemo.rest;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.springboot.springdata.onlinemovieticketbookingdemo.entity.Booking;
import com.springboot.springdata.onlinemovieticketbookingdemo.service.BookingService;

@Service
@RestController
public class BookingRestController {

	private BookingService bookingService;
	
	@Autowired
	public BookingRestController(BookingService theBookingService) {
		bookingService = theBookingService;
	}
	
	
	@GetMapping("/bookingId")
	public List<Booking> findAll() {
		return bookingService.findAll();
	}

	// add mapping for GET /employees/{employeeId}
	
	@GetMapping("/Booking/{bookingId}")
	public Booking getBooking(@PathVariable int bookingId) {
		
		Booking theBooking = bookingService.findById(bookingId);
		
		if (theBooking == null) {
			throw new RuntimeException("Booking id not found - " + bookingId);
		}
		
		return theBooking;
	}
	
	
	
	@PostMapping("/bookingId")
	public Booking addBooking(@RequestBody Booking theBooking) {
		
		theBooking.setBookingid(0);
		
		bookingService.save(theBooking);
		
		return theBooking;
	}
	
	@PutMapping("/bookingId")
	public Booking updateBooking(@RequestBody Booking theBooking) {
		
		bookingService.save(theBooking);
		
		return theBooking;
	}
	
	@DeleteMapping("/booking/{bookingId}")
	public String deleteBooking(@PathVariable int bookingId) {
		
		Booking tempBooking = bookingService.findById(bookingId);
		
		// throw exception if null
		
		if (tempBooking == null) {
			throw new RuntimeException("Booking id not found - " + bookingId);
		}
		
		bookingService.deleteById(bookingId);
		
		return "Deleted booking id - " + bookingId;
	}
	
}
