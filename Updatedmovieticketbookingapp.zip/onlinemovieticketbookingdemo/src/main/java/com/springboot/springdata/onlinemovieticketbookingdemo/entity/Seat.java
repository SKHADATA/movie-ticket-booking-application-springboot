package com.springboot.springdata.onlinemovieticketbookingdemo.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "seat_details")
public class Seat {
	
	@Id
	@Column(name="seatId")
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator = "seatId_generator")
	@SequenceGenerator(name="seatId_generator",initialValue = 20003000,allocationSize = 10001,sequenceName = "seatId_seq")
	

	private Integer seatId;
	//private BookingState seatStatus;
	private  String seatNumber;
	private double seatPrice;
	
	@ManyToOne
	@JoinColumn(name = "show_id")
	private Show show;

	public Seat() {
	}

	@Override
	public String toString() {
		return "Seat [seatId=" + seatId + ", seatNumber=" + seatNumber + ", seatPrice=" + seatPrice + "]";
	}

	public Seat(Integer seatId,   String seatNumber , double seatPrice, Show show) {
		super();
		this.seatId = seatId;
		//this.seatStatus = seatStatus;
		this.seatNumber=seatNumber;
		this.seatPrice = seatPrice;
		this.show = show;
	}

	public Integer getSeatId() {
		return seatId;
	}

	public void setSeatId(Integer seatId) {
		this.seatId = seatId;
	}

	public String getSeatNumber() {
		return seatNumber;
	}

	public void setSeatNumber(String seatStatus) {
		this.seatNumber = seatNumber;
	}

	public double getSeatPrice() {
		return seatPrice;
	}

	public void setSeatPrice(double seatPrice) {
		this.seatPrice = seatPrice;
	}

	public Show getShow() {
		return show;
	}

	public void setShow(Show show) {
		this.show = show;
	}

}
