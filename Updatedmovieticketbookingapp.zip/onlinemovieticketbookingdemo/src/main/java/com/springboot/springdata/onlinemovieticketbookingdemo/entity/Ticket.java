package com.springboot.springdata.onlinemovieticketbookingdemo.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;

@Entity
@Table(name = "ticket_details")
public class Ticket {
	
	@Id
	@GeneratedValue(generator = "ticket_seq")
	@GenericGenerator(name = "ticket_seq", strategy = "org.hibernate.id.enhanced.SequenceStyleGenerator",
    parameters = {
 		   @Parameter(name = "sequence_name", value="ticket_sequence"),
 		   @Parameter(name = "Initial_value", value="12345678"),
 		   @Parameter(name = "increment_size", value="1")
    })
	
	private Integer ticketId;
	private Integer noOfSeat;
	//private Booking bookingRef;
	private Boolean ticketStatus;
	//private String ScreenName;
	//private String seatName;
	public Ticket() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Ticket [ticketId=" + ticketId + ", noOfSeat=" + noOfSeat + 
				 ", ticketStatus=" + ticketStatus + "]";
	}
	public Ticket(Integer ticketId, Integer noOfSeat, Boolean ticketStatus, String screenName,
			String seatName) {
		super();
		this.ticketId = ticketId;
		this.noOfSeat = noOfSeat;
//		this.bookingRef = bookingRef;
		this.ticketStatus = ticketStatus;
		//ScreenName = screenName;
		//this.seatName = seatName;
	}
	public Integer getTicketId() {
		return ticketId;
	}
	public void setTicketId(Integer ticketId) {
		this.ticketId = ticketId;
	}
	public Integer getNoOfSeat() {
		return noOfSeat;
	}
	public void setNoOfSeat(Integer noOfSeat) {
		this.noOfSeat = noOfSeat;
	}
	public void setTicketStatus(Boolean ticketStatus) {
		this.ticketStatus = ticketStatus;
	}
	/*public String getScreenName() {
		return ScreenName;
	}
	public void setScreenName(String screenName) {
		ScreenName = screenName;
	}
	public String getSeatName() {
		return seatName;
	}
	public void setSeatName(String seatName) {
		this.seatName = seatName;
	}*/
}
