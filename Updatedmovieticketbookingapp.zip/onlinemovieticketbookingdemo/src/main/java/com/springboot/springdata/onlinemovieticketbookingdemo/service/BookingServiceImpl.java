package com.springboot.springdata.onlinemovieticketbookingdemo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springboot.springdata.onlinemovieticketbookingdemo.dao.BookingRepository;
import com.springboot.springdata.onlinemovieticketbookingdemo.entity.Booking;

@Service
public class BookingServiceImpl implements BookingService {
	
	private BookingRepository bookingRepository;
	
	@Autowired
	public BookingServiceImpl(BookingRepository bookingRepository) {
		this.bookingRepository = bookingRepository;
	}
	
	public List<Booking> findAll() {
		return bookingRepository.findAll();
	}


	public Booking findById(int theId) {
		Optional<Booking> result = bookingRepository.findById(theId);
		
		Booking theBooking = null;
		
		Booking theBooking1;
		if (result.isPresent()) {
			theBooking1 = result.get();
		}
		else {
			// we didn't find the employee
			throw new RuntimeException("Did not find Projects id - " + theId);
		}
		
		return theBooking1;
	}
	

	
	public void save(Booking theBooking) {
		bookingRepository.save(theBooking);
	}

	
	public void deleteById(int theId) {
		bookingRepository.deleteById(theId);
	}

	@Override
	public List<Booking> getAllBookings() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Booking getBookingById(Long booking_id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Booking pushBooking(Booking newBooking) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Booking updateBooking(Booking updatedBooking, Long booking_id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void deleteBookingById(Long booking_id) {
		// TODO Auto-generated method stub
		
	}
}
