package com.springboot.springdata.onlinemovieticketbookingdemo.entity;


import java.time.LocalDate;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Table(name = "screen_details")
public class Screen {
	
	@Id
	@Column(name="screenId")
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator = "screenId_generator")
	@SequenceGenerator(name="screenId_generator",initialValue = 4000,allocationSize = 1,sequenceName = "screenId_seq")
	
	
	private Integer screenId;
	private String screenName;
	@DateTimeFormat(pattern = "yyyy/MMM/dd")
	private LocalDate movieEndDate;
	@Column(name = "rows_details")
	private Integer rows;
	@Column(name = "columns_details")
	private Integer columns;
	
	@OneToMany(mappedBy = "screen", cascade = CascadeType.ALL)
	private Set<Show> showList= new HashSet<>(); 
	
	@ManyToOne
	@JoinColumn(name = "theater_id")
	private Theater theater;

	public Screen() {
	}

	@Override
	public String toString() {
		return "Screen [screenId=" + screenId + ", screenName=" + screenName + ", movieEndDate=" + movieEndDate
				+ ", rows=" + rows + ", columns=" + columns + ", showList=" + showList + ", theater=" + theater + "]";
	}

	public Screen(Integer screenId, String screenName, LocalDate movieEndDate, Integer rows, Integer columns,
			Set<Show> showList, Theater theater) {
		super();
		this.screenId = screenId;
		this.screenName = screenName;
		this.movieEndDate = movieEndDate;
		this.rows = rows;
		this.columns = columns;
		this.showList = showList;
		this.theater = theater;
	}

	public Screen(String screenName, LocalDate movieEndDate, Integer rows, Integer columns,Theater theater) {
		super();
		this.screenName = screenName;
		this.movieEndDate = movieEndDate;
		this.rows = rows;
		this.columns = columns;
		this.theater = theater;
	}
	public Screen(String screenName, Integer rows, Integer columns) {
		this.screenName = screenName;
		this.rows = rows;
		this.columns = columns;
	}

	public Integer getScreenId() {
		return screenId;
	}

	public void setScreenId(Integer screenId) {
		this.screenId = screenId;
	}

	public String getScreenName() {
		return screenName;
	}

	public void setScreenName(String screenName) {
		this.screenName = screenName;
	}

	public LocalDate getMovieEndDate() {
		return movieEndDate;
	}

	public void setMovieEndDate(LocalDate movieEndDate) {
		this.movieEndDate = movieEndDate;
	}

	public Integer getRows() {
		return rows;
	}

	public void setRows(Integer rows) {
		this.rows = rows;
	}

	public Integer getColumns() {
		return columns;
	}

	public void setColumns(Integer columns) {
		this.columns = columns;
	}

	public Set<Show> getShowList() {
		return showList;
	}

	public void setShowList(Set<Show> showList) {
		this.showList = showList;
	}

	public Theater getTheater() {
		return theater;
	}

	public void setTheater(Theater theater) {
		this.theater = theater;
	}

	public void addShow(Show show) {
		show.setScreen(this);
		showList.add(show);
		
	}
	

	
}
